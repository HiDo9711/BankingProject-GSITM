INSERT INTO kcgbd.t_menu (menu_url,menu_nm,menu_note,reg_user_id,reg_dt,admin_yn) VALUES
	 ('/system/admin_auth_mng/list','관리 그룹 관리','관리 그룹 관리','admin001','2024-07-20 20:19:53.223192','N'),
	 ('/system/menu_mng/list','메뉴관리','메뉴관리','admin001','2024-07-20 20:20:29.99987','N'),
	 ('/system/communi_mng/news/list','공지사항 게시판','공지사항 게시판','admin001','2024-07-20 20:21:16.007461','N'),
	 ('/prod_mng/dtl','상품등록','상품등록','admin001','2024-07-22 09:54:32.283014','N'),
	 ('/custMng/custInfoList','고객정보 목록 조회','고객정보 목록','admin001','2024-07-17 17:00:13.047845','N'),
	 ('/system/portal_auth_mng/list','그룹관리','그룹관리','admin001','2024-07-20 20:19:27.914077','N'),
	 ('/system/menu_mng/dtl','상품관리','상품관리','admin001','2024-05-31 14:41:41.752202','N'),
	 ('/custMng/custInfoMng','고객정보 등록','고객정보 등록','admin001','2024-07-17 17:02:10.12138','N'),
	 ('/prod_mng/list','상품목록 조회','상품목록','admin001','2024-07-17 17:02:56.823162','N'),
	 ('/promion_mng/list','설계이력조회','설계이력조회','admin001','2024-07-20 20:16:54.894492','N');
INSERT INTO kcgbd.t_menu (menu_url,menu_nm,menu_note,reg_user_id,reg_dt,admin_yn) VALUES
	 ('/promion_mng/dtl','금융계산기','금융계산기','admin001','2024-07-20 20:17:18.073466','N'),
	 ('/system/user_mng/list','사용자관리','사용자관리','admin001','2024-07-20 20:18:36.854257','N'),
	 ('/custMng/consultList','고객상담 내역','고객상담 내역','admin001','2024-07-22 17:26:34.528224','N');
