INSERT INTO kcgbd.user_profile (user_id,iam_yn,profile_image_path,reg_dt) VALUES
	 ('admin','N','\KCG\apps\KCG\WebContents\static_resources\system\profile\20240723172158-1.png','2024-07-23 17:21:58.593594'),
	 ('manager','N','\KCG\apps\KCG\WebContents\static_resources\system\profile\20240723174422-1.png','2024-07-23 17:44:22.63199'),
	 ('manager','N','\KCG\apps\KCG\WebContents\static_resources\system\profile\p1.png','2024-07-18 20:24:09.154516'),
	 ('manager2','N','\KCG\apps\KCG\WebContents\static_resources\system\profile\p2.png','2024-07-18 20:24:09.154516'),
	 ('manager3','N','\KCG\apps\KCG\WebContents\static_resources\system\profile\p3.png','2024-07-18 20:24:09.154516'),
	 ('manager4','N','\KCG\apps\KCG\WebContents\static_resources\system\profile\p4.png','2024-07-18 20:24:09.154516'),
	 ('manager5','N','\KCG\apps\KCG\WebContents\static_resources\system\profile\p1.png','2024-07-18 20:24:09.154516'),
	 ('asd','N','\KCG\apps\KCG\WebContents\static_resources\system\profile\20240724121429-1.JPG','2024-07-24 12:14:29.853676'),
	 ('asdf','N','\KCG\apps\KCG\WebContents\static_resources\system\profile\','2024-07-24 14:32:17.219061'),
	 ('manager1','N','\KCG\apps\KCG\WebContents\static_resources\system\profile\p2.png','2024-07-23 18:41:27.992346');
INSERT INTO kcgbd.user_profile (user_id,iam_yn,profile_image_path,reg_dt) VALUES
	 ('123','N','\KCG\apps\KCG\WebContents\static_resources\system\profile\','2024-07-24 15:17:56.56666'),
	 ('qwer','N','\KCG\apps\KCG\WebContents\static_resources\system\profile\20240724152643-1.png','2024-07-24 15:26:44.033551'),
	 ('zxcv','N','\KCG\apps\KCG\WebContents\static_resources\system\profile\20240724155324-1.png','2024-07-24 15:53:24.734647'),
	 ('fdsa','N','\KCG\apps\KCG\WebContents\static_resources\system\profile\20240724155451-1.png','2024-07-24 15:54:52.02023'),
	 ('22','N','\KCG\apps\KCG\WebContents\static_resources\system\profile\','2024-07-24 16:01:13.27554'),
	 ('lkjh','N','\KCG\apps\KCG\WebContents\static_resources\system\profile\20240724160702-1.png','2024-07-24 16:07:02.800873'),
	 ('jhgf','N','\KCG\apps\KCG\WebContents\static_resources\system\profile\20240724163534-1.png','2024-07-24 16:35:35.189086'),
	 ('manager8','N','\KCG\apps\KCG\WebContents\static_resources\system\profile\p1.png','2024-07-18 20:24:09.154516'),
	 ('aasdf','N','\KCG\apps\KCG\WebContents\static_resources\system\profile\20240724164856-1.png','2024-07-24 16:48:56.949226'),
	 ('ddsad','N','\KCG\apps\KCG\WebContents\static_resources\system\profile\20240724171644-1.png','2024-07-24 17:16:44.274639');
INSERT INTO kcgbd.user_profile (user_id,iam_yn,profile_image_path,reg_dt) VALUES
	 ('manager9','N','\KCG\apps\KCG\WebContents\static_resources\system\profile\p1.png','2024-07-18 20:24:09.154516'),
	 ('gildong','N','\KCG\apps\KCG\WebContents\static_resources\system\profile\20240724192534-1.png','2024-07-24 19:25:34.636733'),
	 ('manager10','N','\KCG\apps\KCG\WebContents\static_resources\system\profile\p1.png','2024-07-18 20:24:09.154'),
	 ('kwak','N','\KCG\apps\KCG\WebContents\static_resources\system\profile\p1.png','2024-07-23 16:16:34.378538'),
	 ('zxczxc','N','\KCG\apps\KCG\WebContents\static_resources\system\profile\','2024-07-25 09:50:37.860013'),
	 ('bran','N','\KCG\apps\KCG\WebContents\static_resources\system\profile\p1.png','2024-07-23 16:17:21.559036'),
	 ('bal','N','\KCG\apps\KCG\WebContents\static_resources\system\profile\p1.png','2024-07-23 16:17:59.921703'),
	 ('choi','N','\KCG\apps\KCG\WebContents\static_resources\system\profile\p1.png','2024-07-23 16:19:34.172577'),
	 ('ho','N','\KCG\apps\KCG\WebContents\static_resources\system\profile\p1.png','2024-07-23 16:20:07.691511'),
	 ('manager7','N','\KCG\apps\KCG\WebContents\static_resources\system\profile\p2.png','2024-07-18 20:24:09.154516');
INSERT INTO kcgbd.user_profile (user_id,iam_yn,profile_image_path,reg_dt) VALUES
	 ('manager6','N','\KCG\apps\KCG\WebContents\static_resources\system\profile\p3.png','2024-07-18 20:24:09.154516'),
	 ('admin001','N','\KCG\apps\KCG\WebContents\static_resources\system\profile\p1.png','2024-07-18 20:24:09.154516');
